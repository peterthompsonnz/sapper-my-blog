const password = document.querySelector('.passwords');
const copiedMessage = document.querySelector('#copied-message');
const generateBtn = document.querySelector('input[type=submit]');
generateBtn.setAttribute('disabled', true);

const numWords = document.querySelector('#numberWords');

const copyBtn = document.querySelector('#copy-btn');
copyBtn.addEventListener('click', copyPassword);

// Array of words to choose words that make up password from
let wordsArr;

fetch('./words.txt')
.then(resp => resp.text())
.then(text => text.split('\n'))
.then(array => {
  wordsArr = array; 
  generateBtn.removeAttribute('disabled');
})
.catch(err => console.log(err));

function getRandomItem(array) {
  return array[Math.floor(Math.random() * array.length)];
}

function copyPassword() {
  /* Select the text field */
  password.select();
  password.setSelectionRange(0, 99999); /*For mobile devices*/

  /* Copy the text inside the text field */
  document.execCommand("copy");

  /* Alert the copied text */
  copiedMessage.innerText = "Password copied!";
} 

generateBtn.addEventListener('click', (evt) => {
  evt.preventDefault();
  const _numWords = numWords.value;
  let _password = ``;
  for (let i = 0; i < _numWords; i++) {
    let word = getRandomItem(wordsArr);
    _password += `${word} `;
  }
  password.value = _password.trimEnd();
  copiedMessage.innerText = '';
});



