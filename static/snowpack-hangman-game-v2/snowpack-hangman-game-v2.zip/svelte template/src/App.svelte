<script>
	import { ANIMALS } from './animals.js';
	let word = '';
	let wordGuess = '';
  let secretWord = '';
	let incorrectLetters = '';
	let letter = '';
	const HIDDEN_CHAR = '*';
	const maxGoes = 10;
	let numGoes = 0;
	let checkLetterButton, checkWordButton;
  let letterTextbox, wordTextbox;

	$: goesLeft = maxGoes - numGoes;	
	$: successMessage = !word.includes(HIDDEN_CHAR) ? `Good job! You have guessed that the word was: <strong>${secretWord}</strong>` : ``;
	$: failureMessage = goesLeft <= 0 ? `Game over. You have used up all your guesses. The word was: <strong>${secretWord}</strong>` : ``;
	$: letter = letter.toLowerCase();
	
	secretWord = getSecretWord();
	for (let i = 0; i < secretWord.length; i++) { 
		word += HIDDEN_CHAR;	
	}

	function getSecretWord() {
		const index = Math.floor(Math.random() * ANIMALS.length); 
		return ANIMALS[index].toLowerCase();
	}
	
	function checkLetterGuess() {		
		if (letter.length !== 1) {
			alert("Enter one character at a time");
			return;
		}
		if (!(letter >= 'a' && letter <= 'z') && !(letter >= 'A' && letter <= 'Z')) {
			alert("The letter must be in the alphabet");
			return;
		}
		let indices = [];
		if (secretWord.includes(letter)) {			
			for (let i = 0; i < secretWord.length; i++) {
				if (secretWord[i] === letter) {
					indices.push(i);
				}
			}			
			adjustWord(letter, indices);
		} else {
			numGoes += 1;
			incorrectLetters += letter; 
		}
		if (successMessage || failureMessage) {
			checkLetterButton.disabled = true;
		}
    letterTextbox.value = '';
	}

	function checkWordGuess() {
		if (wordGuess.trim().toLowerCase() === secretWord) {
			word = secretWord;
		} else {
			goesLeft -= 5;
			wordGuess = '';
		}
	};
	
	function adjustWord(letter, indices) {
		// Create an array from the letters in 'word'
		// because it is easier to replace letters in an array because they are mutable
		// whereas strings, which 'word' is an instance of, are not.
		const wordArray = [...word];
		for (let i = 0; i < indices.length; i++) {
			let index = indices[i];
			wordArray[index] = letter;
		}		
		// word is 'new' as far as Svelte is concerned so there will be a re-render
		word = wordArray.join('');		
	}
		
</script>
<main>
	<h1>
		Hangman Game
	</h1>
  <p>The word to guess is an animal's name. Each <strong>letter</strong> guess costs 1 go. Each <strong>word</strong> guess costs 5 goes.</p>
	<div>Goes left: 
		{goesLeft}
	</div>
	<div><span on:click={() => alert(secretWord)}>Word</span>: <span class="letters">
		{word}</span>
	</div>
	<div>Incorrect letters: <span class="letters">
		{[...incorrectLetters]}</span>
	</div>
	<div style="width: 340px;">
		<div>		
			<label style="display:inline-block;margin-right:3px;">Letter:</label><input class="letter-guess-input" type="text" bind:value={letter} bind:this={letterTextbox} />			
			<button on:click={checkLetterGuess} bind:this={checkLetterButton}>Check Letter</button>
		</div>
		<div>		
			<label style="display:inline-block;margin-right:2px;">Word:</label>
			<input class="word-guess-input" type="text" bind:value={wordGuess} bind:this={wordTextbox} />		
			<button on:click={checkWordGuess} bind:this={checkWordButton}>Check Word</button>
		</div>
	</div>
	<div>	
	{#if successMessage}
		<span class="game-over">{@html successMessage}</span>
	{:else if failureMessage}
			<span class="game-over">{@html failureMessage}</span>
	{/if}
	</div>
</main>

<style>  
  :global(body) {
    background-color: #fefefe;
    font-family: arial, helvetica, sans-serif;
    font-size: 100%;
  }
	main {
		font-size: 1.25rem;
    margin: 0 auto;
    max-width: 480px;    
	}
	h1 {
		font-size: 2.25rem;
		text-transform: uppercase;
		letter-spacing: 1px;
		color: crimson;
	}
	p {
		line-height: 1.3;
	}
	div {
		margin: 1.5rem 0;
	}	
	.letters {
		color: var(--text-emphasis-color);
		font-weight: 600;		
		letter-spacing: 2px;
	}
	.game-over {
		color: var(--text-emphasis-color);
    font-size: 1.25rem;
    line-height: 1.5;
	}	
	input[type=text] {	
    font: inherit;    
		padding: 0.15em;			
		border: 2px inset #999;		
	}
	.letter-guess-input {
		width: 2em;
		text-align: center;
	}
	.word-guess-input {
		width: 7em;		
	}	
	button {
		background-color: #fafafa; 
    color: crimson;		
		border: 2px outset crimson;
		padding: 0.1rem 0.25rem;
		font-size: inherit;
		cursor: pointer;    
	} 
	button:active {
			transform: scale(0.95);
	}
	input[type=text], button {
		border-radius: 2px;
	}
</style>
