module.exports = {
  ...require("@snowpack/app-scripts-svelte/jest.config.js")(),
};
