<script>
  import People from "./People.svelte";
  let pageNumber = 1;
  let disableNext = false;
  let disablePrevious = false;

  const handleMessage = (evt) => {
    const message = evt.detail;
    if (message.next !== null && message.previous !== null) {
      disableNext = false;
      disablePrevious = false;
    } else if (message.next === null) {
      disableNext = true;
    } else if (message.previous === null) {
      disablePrevious = true;
    }
  };
</script>

<style>
  :global(body) {
    font-family: helvetica, arial, sans-serif;
    font-size: 105%;
    margin: 0 auto;
    max-width: 480px;
    padding: 0.5em;
    background-color: #333;
    color: #ccc;
  }
  h1 {
    font-size: 2.25em;
    font-weight: 300;
    color: #ff3e00;
    margin: 0.75em 0;
  }
  h2 {
    font-size: 1.75em;
    font-weight: 300;
    color: dodgerblue;
    margin: 0.75em 0 1.5em 0;
  }
  button {
    border: 2px solid #ccc;
    outline: none;
    background-color: transparent;
    color: #ccc;
    padding: 5px 10px;
    border-radius: 6px;
  }
  button:hover {
    color: dodgerblue;
    border-color: dodgerblue;
    background-color: transparent;
  }
  button:active {
    color: crimson;
    border-color: crimson;
    background-color: transparent;
  }
  button:disabled,
  button[disabled] {
    border-color: #666;
    color: #666;
  }
  .page-number {
    font-size: 1.25em;
    display: inline-block;
    margin: 0 0.25em;
    color: #ccc;
  }
</style>

<h1>Star Wars API - SWAPI</h1>
<h2>People</h2>
<div class="buttons">
  <button disabled={disablePrevious} on:click={() => (pageNumber -= 1)}>
    Previous
  </button>
  <button disabled={disableNext} on:click={() => (pageNumber += 1)}>
    Next
  </button>
  <span class="page-number">Page: {pageNumber}</span>
</div>
<People {pageNumber} on:message={handleMessage} />
