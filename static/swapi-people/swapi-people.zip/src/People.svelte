<script>
  import Person from "./Person.svelte";
  import { createEventDispatcher } from "svelte";
  const dispatch = createEventDispatcher();
  let loading = true;
  let URL = `//swapi.dev/api/people/?page=`;
  export let pageNumber;

  $: people = getPeople(pageNumber);

  const getPeople = async (pageNum) => {
    const resp = await fetch(`${URL}${pageNum}`);
    const json = await resp.json();
    if (resp.ok) {
      dispatch("message", {
        next: json.next,
        previous: json.previous,
      });
      return json.results;
    } else {
      throw new Error(`Error fetching people data. Status: ${resp.status}`);
    }
  };
</script>

{#await people}
  <p>Waiting...</p>
{:then data}
  {#each data as { name, gender, homeworld, birth_year } (name)}
    <Person {name} {gender} {homeworld} {birth_year} />
  {/each}
{:catch error}
  <p style="color: red">{error.message}</p>
{/await}
