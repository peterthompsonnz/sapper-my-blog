<script>
  export let name = "";
  export let gender = "";
  export let homeworld = "";
  export let birth_year = "";
</script>

<style>
  div {
    box-shadow: 0 2px 4px rgba(255, 255, 255, 0.36);
    border-radius: 6px;
    background-color: #222;
    padding: 10px;
    margin: 1em 0;
  }
  h2 {
    color: #ab79d6;
    margin: 0.25em 0;
    padding: 0;
    font-weight: 300;
    font-size: 1.5em;
  }
  p {
    color: #fefefe;
  }
  a {
    color: dodgerblue;
  }
  a:hover {
    color: blue;
  }
</style>

<div>
  <h2>{name}</h2>
  <p>Gender: {gender ? gender : '[unkown]'}</p>
  <p>Birth year: {birth_year ? birth_year : '[unkown]'}</p>
  <p>
    Homeworld:
    <a href={homeworld ? homeworld : '#'} title="home world">
      {homeworld ? homeworld : '[unkown]'}
    </a>
  </p>
</div>
