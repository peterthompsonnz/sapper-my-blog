<script>
	import Board from './components/Board.svelte';
	export let title = '';
</script>

<style>
  :global(*) {
    box-sizing: border-box;
  }  
  :global(body) {
    margin: 0;
    font-family: helvetica, arial, sans-serif;
    font-size: 18px;
    color: rgba(0, 0, 0, 0.95);    
  }
  h1 {	 		
    margin: 0.75em 0 0.5em 0;
    font-size: 1.75em;
  }	
  main {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
    margin: 0 auto;
    max-width: 480px;		
  }
</style>
<main>
  <h1> { title } </h1>
  <Board />	
</main>
