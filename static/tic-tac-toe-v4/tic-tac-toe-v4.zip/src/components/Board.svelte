<script>
  import Square from "./Square.svelte";
  const fillChar = '';
  let tie = false;
  let status = '';
  let winner = '';
  
  let xScore = 0;
  let xEmoji = "🚒";
  let oEmoji = "🛩️";
  let oScore = 0;
  
  let squares = Array(9).fill(fillChar);

  let xIsNext = Math.random() < 0.5 ? true : false; 

  $: winner = calculateWinner(squares);

  $: {
    if (winner) {
      status = `Winner is: <span class="emoji">${winner}!</span>`;
    } else if (tie) {
      status = `Tie. Click New Game`;
    } else {
      status = `Next player: `;
      if (xIsNext) {
        status += `${xEmoji}`;
      } else {
        status += `${oEmoji}`;
      }
    }    
  }
    

  function handleClick(i) {
    const square = squares[i];
    if (winner || tie || square !== fillChar) {
      return;
    }    
    squares[i] = xIsNext ? xEmoji : oEmoji;  
    tie = !squares.includes(fillChar);
    xIsNext = !xIsNext;
  }

  function calculateWinner(squares) {
    const lines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6]
    ];
    let square;
    for (let i = 0; i < lines.length; i++) {
      const [a, b, c] = lines[i];
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        square = squares[a];
        if (square === '🚒') {
          xScore++;
        } else {
          oScore++;
        }
        return square;
      }
    }
    return null;
  }

  function newGame() {
    winner = '';
    status = '';
    tie = false;
    squares = Array(9).fill(fillChar);
    xIsNext = Math.random() < 0.5 ? true : false;
  };
  
</script>

<style>
  .board {
	 margin: 0.5em 0;
   padding-bottom: 1em;   
	}
  .board-row:after {
    clear: both;
    content: "";
    display: table;
  }  
  .status {    
    font-size: 1.35em;
    text-align: center;
    margin: 0.25em 0;
  }
  .dashboard {           
    display: flex;
    justify-content: space-between;
    min-height: 100px;
  }  
  .scores h2 {
    margin: 0.4em 0 0.3em 0;
    font-size: 1.35em;
    font-weight: 400;
  }
  .score {
    margin: 0.3em 0;
    font-size: 1.35em;
  }
  .new-game-container {
    display: flex;
    flex-direction: column;
    justify-content: center;        
  }
  .new-game-container button {    
    font-size: 0.95em;
    background-color: #de384d;
    color: white;
    padding: 0.35em 0.75em;
    border: 1px solid #ccc;
    border-radius: 6px;   
  }
  .new-game-container button:hover {
    background-color: #de182d;
  }
  
</style>

<p class="status"> {@html status} </p>
<div class="board">  
  <div class="board-row">
    <Square value={squares[0]} handleClick={() => handleClick(0)}/>
    <Square value={squares[1]} handleClick={() => handleClick(1)}/>
    <Square value={squares[2]} handleClick={() => handleClick(2)}/>
  </div>

  <div class="board-row">
    <Square value={squares[3]} handleClick={() => handleClick(3)} />
    <Square value={squares[4]} handleClick={() => handleClick(4)} />
    <Square value={squares[5]} handleClick={() => handleClick(5)} />
  </div>


  <div class="board-row">
    <Square value={squares[6]} handleClick={() => handleClick(6)} />
    <Square value={squares[7]} handleClick={() => handleClick(7)} />
    <Square value={squares[8]} handleClick={() => handleClick(8)} />
  </div>

  <div class="dashboard">
    <div class="scores"><h2>Scores</h2>
      <p class="score">{xEmoji}: {xScore}</p>
      <p class="score">{oEmoji}: {oScore}</p>
    </div>
    <div class="new-game-container">
      <button on:click={newGame}>New Game</button>
    </div>    
  </div>  
</div>


