<style>
  .game {
      display: flex;
      flex-direction: row;
  }  
</style>

<script> 
    import Board from './Board.svelte';
</script>

<div class="game">  
  <Board />
</div> 
