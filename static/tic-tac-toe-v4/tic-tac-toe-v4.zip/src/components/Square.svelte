<script>
  export let value; 
  export let handleClick;
  
</script>

<style>
 .square {
    background: #fff;    
    border: 1px solid #333;
    float: left;
    font-size: 36px;
    font-weight: bold;
    line-height: 1.5;
    height: 2.25em;
    width: 2.25em;   
    margin: -1px -1px 0 0;
    padding: 0;
    text-align: center;   
  }

 .square:focus {
    outline: none;
    background: #ddd;
 }
</style>

<button class="square" on:mousedown={handleClick}> {value} </button>
