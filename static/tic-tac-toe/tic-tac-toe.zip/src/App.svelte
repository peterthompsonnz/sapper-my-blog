<script>
	import Board from './Board.svelte';
	export let title = '';
</script>

<style>
	:global(body) {
		margin: 0;
		font-family: verdana, arial, sans-serif;
		font-size: 18px;
		color: rgba(0, 0, 0, 0.95);
	}
	h1 {	   
		font-family: georgia, times, erif; 
	    margin: 0.5em 0;
	}	
	main {
		display: flex;
		flex-direction: column;
		justify-content: flex-start;
		align-items: center;
		margin: 0 auto;
		max-width: 640px;	
	}
</style>
<main>
	<h1> { title } </h1>
	<Board />
</main>