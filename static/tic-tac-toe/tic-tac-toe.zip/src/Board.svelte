<script>
  import Square from "./Square.svelte";
  const fillChar = '';
  let tie = false;
  let status = '';  
  let xIsNext = Math.random() < 0.5 ? true : false;
  
  
  const winLines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6]
    ];

  let squares = Array(9).fill(fillChar);

  $: winner = calculateWinner(squares);

  $: {
	  	if (winner) {
	  		status = `Winner is: ${winner}. Refresh to play again`;
	  	} else if (tie) {
	  		status = `Tie. Refresh to play again`;
	  	} else {
	  		status = `Next player: ${xIsNext ? "X" : "O"}`;
	  	}
  	}    

  function handleClick(i) {
    if (winner || tie) {
      return;
    }    
    squares[i] = xIsNext ? "X" : "O";  
    tie = !squares.includes(fillChar);
    xIsNext = !xIsNext;
  }

  function calculateWinner(squares) {
    
    for (let i = 0; i < winLines.length; i++) {
      const [a, b, c] = winLines[i];
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    return null;
  }
</script>

<style>
  .board {
	 margin: 0.5em 0;
	}
  .board-row:after {
    clear: both;
    content: "";
    display: table;
  }  
  .status {    
    font-size: 22px;
    text-align: center;
    margin: 0.25em 0;
  }
</style>

<div class="status"> {status} </div>
<div class="board">  
  <div class="board-row">
    <Square value={squares[0]} handleClick={() => handleClick(0)}/>
    <Square value={squares[1]} handleClick={() => handleClick(1)}/>
    <Square value={squares[2]} handleClick={() => handleClick(2)}/>
  </div>

  <div class="board-row">
    <Square value={squares[3]} handleClick={() => handleClick(3)} />
    <Square value={squares[4]} handleClick={() => handleClick(4)} />
    <Square value={squares[5]} handleClick={() => handleClick(5)} />
  </div>


  <div class="board-row">
    <Square value={squares[6]} handleClick={() => handleClick(6)} />
    <Square value={squares[7]} handleClick={() => handleClick(7)} />
    <Square value={squares[8]} handleClick={() => handleClick(8)} />
  </div>
</div>
